var user=[
    {
        id:1,
        name:'name1'
    },
    {
        id:2,
        name:'name2'
    },
    {
        id:3,
        name:'name3'
    }
 
]
var commnets=[
    {
        id:1,
        user_id:1,
        content:'cm1'
    },
    {
        id:1,
        user_id:2,
        content:'cm2'
    }
]

// 1 Lấy comment
// 2 từ comments user_id
//3 từ user id lấy ra user tương ứng
// 
function getComment(){
    return new Promise(function(resole){
        setTimeout(function(){
            resole(commnets)
        })
    })
}
getComment()
    .then(function(comments){
        var userIDs=commnets.map(function(comment){
            return comment.user_id;
        })
        console.log(userIDs, 'test userid')
    })