// la mot dinh dang du lieu dang chuoi
// js ọne

// stringify: Từ js types--> Json
// Parse: jsson --> js
// var json='["js","php"]'; // array
// var json='{"name":"value","age":23}'; // object
// var a='"truejson"'
console.log(JSON.parse(a))

//sync/async
//Async
//setTimeout, setInterval, fetch, XMLHttpRequest, file reading, requestAnimationFrame