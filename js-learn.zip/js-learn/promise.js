// Thay the call back hell

// Khởi tạo
// tạo ra excutor
var promise = new Promise(
  // Excutor
  function (resole, reject) {
    // logic tự viết
    // thành công resolve()
    // thất bại reject()
    resole("co loi");
  }
);
promise
  //Chay voi resolve
  .then(function () {
    console.log("successully!");
    // run with reject
    return true;
  })
  .then(function (data) {
    console.log(data);
    // run with reject
  })
  .catch(function (fail) {
    console.log(fail);
  })
  .finally(function () {
    console.log("finally!");
  });

// tinh chat cua promise



var promise1 = new Promise(
    function(resolve){
        setTimeout(function(){
            resolve([1]);
        },2000)
    }
)
var promise2 = new Promise(
    function(resolve){
        setTimeout(function(){
            resolve([2,3]);
        },1000)
    }
)
Promise.all([promise1,promise2])
    .then(function(result){
      console.log(result[0].concat(result[1]))  
    })