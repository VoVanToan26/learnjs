var inputE = document.querySelector('input[type="text"]');
// console.log(inputE)
// .ONCHANGE hoặc ONINPUT
// inputE.oninput = function (e) {
//   console.log(e.target.value);
// };
inputE.onkeyup = function (e) {
    console.log(e.which)
    switch(e.which){
        case 38:
            console.log("Up")
            break;
        case 40:
            console.log("Down")
            break;
    }
  };



var inputC = document.querySelector('input[type="checkbox"]');
// console.log(inputC)
inputC.onchange = function (e) {
  console.log(e.target.checked);
};
var inputC = document.querySelector('select');
// console.log(inputC)
inputC.onchange = function (e) {
  console.log(e.target.value);
};

var aElement=document.querySelectorAll('a')
console.log(aElement)
for(var i=0;i<aElement.length;i++){
    aElement[i].onclick=function(e){
        if(!e.target.href.startsWith('https://www.facebook.com/')){
            e.preventDefault();
            // console.log(e.preventDefault())
            console.log('true')
        }else console.log(false)
    }
    
}
// stopPropagation
document.querySelector('div').onclick=function(){
    console.log('div click')
}
document.querySelector('button').onclick=function(e){
    e.stopPropagation();
    console.log('button')
}
