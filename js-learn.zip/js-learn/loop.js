/**
 for 
 for/in lap qua key
 for/of lap cho value
 while
    do/while
 */

