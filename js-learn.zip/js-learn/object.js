/*
var emailKey='email'
var myInfo={
    name:'Son Dang',
    age:18,
    address:"VN",
    [emailKey]:"mail.test",
    getName: function(){
        return this.name  //this=myInfo
    }
    // getName là phương thức method
    // age  thuộc tính property

}
console.log(myInfo[emailKey])
var myKey='address'
myInfo.address
myInfo[myKey]

*/
/*
// object constructor
function User(firstName, lastName, avatar){
    this.firstName= firstName;
    this.lastName= lastName;
    this.avatar = avatar;
    this.getname=function(){
        return `${this.firstName}${this.lastName}`
    }
}
//  add prototype
User.prototype.className="f823423423"
User.prototype.getClassName=function(){
    return this.className
}

var author= new User("Sơn","Đặng","avatar")
author.title="Thêm title cho object để"
console.log(author)
console.log(author.className)
console.log(author.getClassName())


*/
// Date
var date=new Date();
var year=date.getFullYear();
var month=date.getMonth()+1;
var day=date.getDate();
console.log(date.getFullYear)
console.log(`${year}  ${month}  ${day}`)


/*
Math object
 */
var random= Math.floor(Math.random()*100)
if (random<20) {
    console.log("Cường hóa thành công")
}