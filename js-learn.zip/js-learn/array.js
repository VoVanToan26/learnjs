
var courses = [
    {
    id:1,
    name:"js",
    coin:0
},
{
    id:2,
    name:"js2",
    coin:3
},{
    id:3,
    name:"js3",
    coin:10
}
]

// console.log(Array.isArray(languages))
//  keyword js array methods
/*
1. ToString
2.  pop()  xóa phần tử cuối mảng trả về phần tử đã xóa
3   .push() thêm phần tử vào cuối mảng và trả về chiều dài của mảng đó
4.  .shift()   Xóa phần tử đầu mảng và trả về giá trị xóa
5   .unshift('')
6   .splice()  Xóa phần tử , chèn phần tử
7   .concat()  Nối array
8   slice cắt mảng
*/

// MAP
//Map trả về phần tử mảng có số phần tử bằng số phần tử gốc
var newCourses= courses.map(function(course,index, array) {
    // return{
    //     id:course.id,
    //     name:`Khoa hoc: ${course.name}`,
    //     coin: course.coin,
    //     coinText:`Gia ${course.coin}`,
    //     index: index,
    // }

    return course.name
});
console.log(newCourses)

// REDUCE
//  use for to handle = reduce
// var toTalCoin =0;
// for ( var course of  courses){
//     toTalCoin+=course.coin;
// }
// console.log(toTalCoin)
function coinHandler(accumulater,currentValue,currentIndex, array){
    console.log(accumulater)
    
}
var totalCoin=courses.reduce(coinHandler,0)