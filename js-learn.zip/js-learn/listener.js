// console.log('true')
var btn=document.getElementById('btn')
console.log(btn)
function viec1(){
    console.log('viec1')
}
function viec2(){
    console.log('viec12')
}
function viec3(){
    console.log('viec1')
}

// btn.addEventListener('click',function(e){
//    viec1(1)
// })
btn.addEventListener('click',viec1)
btn.addEventListener('click',viec2)

setTimeout(function(){
    btn.removeEventListener('click',viec1)
},1000)