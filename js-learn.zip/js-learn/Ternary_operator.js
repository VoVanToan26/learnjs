var course={
    name:'Java',
    coin:-1,
}

var result=course.coin>0 ? `${course.coin} Coins`: 'Free';
console.log(result);
 var a=1 
 var b=2
 var c=a>0 ? a:b
